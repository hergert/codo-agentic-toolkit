Dotclaude docs placeholder.
