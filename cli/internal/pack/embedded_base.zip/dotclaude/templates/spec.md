# Feature Spec: $1

## Problem & Goal
(What user story are we solving? Success criteria?)

## Acceptance Criteria
- [ ] …
- [ ] …

## Risks / Constraints
- Perf / Security / Migration notes

## Test Plan (write these tests first)
- [ ] Unit: …
- [ ] Integration: …
- [ ] E2E: …

## Rollout & Monitoring
- Flag: … | Metrics: … | Rollback: …

