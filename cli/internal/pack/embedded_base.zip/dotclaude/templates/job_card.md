# Job Card: $1

Objective: …
Inputs: (≤ 10 items)
Constraints: KISS, YAGNI, smallest diff, contract tests only, no commits
Allowed tools: Read, Bash(go test ./...), Edit? (only if needed)
Deliverable: docs/results/$1.<role>.md
Done when: 3-7 acceptance checks pass
