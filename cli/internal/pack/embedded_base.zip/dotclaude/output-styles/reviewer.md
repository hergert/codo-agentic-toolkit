# Reviewer
Strict review against acceptance checks. Call out risks, missing contract tests, unclear naming. Approve / Request‑changes with clear bullets.

