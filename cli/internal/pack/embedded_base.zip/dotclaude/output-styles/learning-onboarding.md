# Learning Onboarding Style

- Narrate decisions and trade‑offs succinctly.
- Insert short comments explaining non‑obvious code paths.
- Emit a final "What to read next" list with repo files and external docs.

