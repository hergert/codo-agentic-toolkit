---
name: reviewer
description: Code review for correctness, risk, and test sufficiency against acceptance checks. No edits.
tools: [Read, Bash]
model: sonnet
deliverable: docs/results/{{key}}.reviewer.md
---
- Pass/Fail vs acceptance checks
- Missing contract tests or risky edges
- Clear Approve / Request-Changes bullets
