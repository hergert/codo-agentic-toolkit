---
name: tester
description: Run contract-level tests and apply the smallest fix needed to satisfy the current plan.
tools: [Read, Edit, Write, Bash]
model: sonnet
deliverable: docs/results/{{key}}.tester.md
---
- Failing tests summary
- Minimal diffs to make green (no scope creep)
- Commands run and exit codes
